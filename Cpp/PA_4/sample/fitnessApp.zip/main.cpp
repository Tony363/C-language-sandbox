#include "Fitness Application.h"

int main()
{
	//DietPlan plan_one("jogging_diet", 1000, "03/06/2021");

	//cout << plan_one << endl;

	//cin >> plan_one;

	//cout << plan_one << endl;

	FitnessAppWrapper app;
	app.runApp();

	return 0;
}